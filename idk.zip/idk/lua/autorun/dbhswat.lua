if SERVER then
	AddCSLuaFile()
end

player_manager.AddValidModel("Detroit - SWAT Captain Allen", "models/konnie/isa/detroit/swat_captainallen.mdl")
player_manager.AddValidHands( "Detroit - SWAT Captain Allen", "models/weapons/arms/v_arms_detroit_swat.mdl", 0, "00000000" )

player_manager.AddValidModel("Detroit - SWAT Soldier", "models/konnie/isa/detroit/swat_soldier.mdl")
player_manager.AddValidHands( "Detroit - SWAT Soldier", "models/weapons/arms/v_arms_detroit_swat.mdl", 0, "00000000" )

player_manager.AddValidModel("Detroit - SWAT Soldier Balaclava", "models/konnie/isa/detroit/swat_soldier_2.mdl")
player_manager.AddValidHands( "Detroit - SWAT Soldier Balaclava", "models/weapons/arms/v_arms_detroit_swat.mdl", 0, "00000000" )